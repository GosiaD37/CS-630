"""Unit tests for the Roman numeral conversion library."""

import pytest

from lib_roman_to_int import from_roman


def test_from_roman_I_returns_1():
    assert from_roman("I") == 1


@pytest.mark.parametrize(
    ("roman", "expected"),
    [
        ("III", 3),
        ("VIII", 8),
        ("XXIII", 23),
        ("CLXXVI", 176),
        ("MMXXVI", 2026),
    ],
)
def test_additive_roman_numerals(roman, expected):
    assert from_roman(roman) == expected


@pytest.mark.parametrize(
    ("roman", "expected"),
    [
        ("IV", 4),
        ("IX", 9),
        ("XL", 40),
        ("XC", 90),
        ("CD", 400),
        ("CM", 900),
    ],
)
def test_allowed_subtractive_pairs(roman, expected):
    assert from_roman(roman) == expected


def test_complex_roman_numeral_returns_expected_value():
    assert from_roman("MCMXCIV") == 1994


def test_upper_boundary_returns_3999():
    assert from_roman("MMMCMXCIX") == 3999


@pytest.mark.parametrize(
    "invalid_roman",
    [
        "",
        "IIII",
        "VV",
        "IL",
        "IC",
        "XM",
        "ABC",
        "iv",
        "MMMM",
    ],
)
def test_invalid_roman_numerals_raise_value_error(invalid_roman):
    with pytest.raises(ValueError, match="Invalid Roman numeral"):
        from_roman(invalid_roman)


def test_non_string_input_raises_type_error():
    with pytest.raises(TypeError, match="must be provided as a string"):
        from_roman(10)
