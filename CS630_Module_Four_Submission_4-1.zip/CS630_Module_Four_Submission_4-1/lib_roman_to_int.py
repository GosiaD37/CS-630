"""Roman numeral conversion library for CS 630 Module Four Activity."""

import re

_ROMAN_VALUES = {
    "I": 1,
    "V": 5,
    "X": 10,
    "L": 50,
    "C": 100,
    "D": 500,
    "M": 1000,
}

# Standard Roman numerals from 1 through 3,999.
_VALID_ROMAN_PATTERN = re.compile(
    r"^M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$"
)


def from_roman(roman_string: str) -> int:
    """Convert a standard Roman numeral to an integer.

    The function accepts uppercase Roman numerals in the conventional range
    from I (1) through MMMCMXCIX (3,999). Invalid or empty numeral strings
    raise ValueError. Non-string inputs raise TypeError.

    Args:
        roman_string: Roman numeral to convert.

    Returns:
        The decimal integer represented by ``roman_string``.

    Raises:
        TypeError: If ``roman_string`` is not a string.
        ValueError: If the string is empty or is not a standard Roman numeral.
    """
    if not isinstance(roman_string, str):
        raise TypeError("Roman numeral must be provided as a string.")

    if not roman_string or not _VALID_ROMAN_PATTERN.fullmatch(roman_string):
        raise ValueError("Invalid Roman numeral.")

    total = 0
    for index, symbol in enumerate(roman_string):
        value = _ROMAN_VALUES[symbol]
        next_value = (
            _ROMAN_VALUES[roman_string[index + 1]]
            if index + 1 < len(roman_string)
            else 0
        )

        if value < next_value:
            total -= value
        else:
            total += value

    return total
