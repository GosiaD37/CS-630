import json
import pytest

from stand_up_api_word_count import app


@pytest.fixture
def client():
    """
    Creates a Flask test client so the API can be tested without manually
    opening a browser or sending requests to a separately running server.
    """
    app.config["TESTING"] = True

    with app.test_client() as test_client:
        yield test_client


# ---------------------------------------------------------
# Basic functionality tests
# ---------------------------------------------------------

def test_get_single_word(client):
    """
    Verifies that the GET /count endpoint correctly counts one word.

    This test is important because it confirms that the endpoint works
    correctly for the simplest valid input.
    """
    response = client.get("/count?text=hello")

    assert response.status_code == 200

    data = json.loads(response.data)
    assert data["count"] == 1


def test_get_two_words(client):
    """
    Verifies that the GET /count endpoint correctly counts two words.

    This test confirms that the API can recognize separate words when
    a valid sentence is provided.
    """
    response = client.get("/count?text=hello world")

    assert response.status_code == 200

    data = json.loads(response.data)
    assert data["count"] == 2


# ---------------------------------------------------------
# Edge-case tests for GET requests
# ---------------------------------------------------------

def test_empty_string(client):
    """
    Verifies that the API handles an empty string without crashing.

    Empty input is an important edge case because users or client
    applications may submit the text parameter without entering any text.
    The expected result is a word count of zero.
    """
    response = client.get("/count?text=")

    assert response.status_code == 200

    data = json.loads(response.data)
    assert data["count"] == 0


def test_whitespace_only(client):
    """
    Verifies that input containing only spaces is treated as having no words.

    This test is important because whitespace-only input is technically not
    empty, but it should not be counted as valid words.
    """
    response = client.get(
        "/count",
        query_string={"text": "     "}
    )

    assert response.status_code == 200

    data = json.loads(response.data)
    assert data["count"] == 0


def test_long_string(client):
    """
    Verifies that the API can process a very long string.

    This test evaluates how the API behaves under a larger input load.
    Long inputs may expose performance problems, size limitations, or
    processing errors.
    """
    text = "word " * 1000

    response = client.get(
        "/count",
        query_string={"text": text}
    )

    assert response.status_code == 200

    data = json.loads(response.data)
    assert data["count"] == 1000


def test_unicode_text(client):
    """
    Verifies that the API correctly processes Unicode characters.

    Unicode testing is important because modern applications may receive
    international text and non-English characters from users around the world.
    """
    response = client.get(
        "/count",
        query_string={"text": "こんにちは 世界"}
    )

    assert response.status_code == 200

    data = json.loads(response.data)
    assert data["count"] == 2


def test_missing_parameter(client):
    """
    Verifies how the API responds when the required text parameter is missing.

    Missing values are a common input risk. This test helps determine whether
    the API handles the missing parameter gracefully instead of crashing.
    """
    response = client.get("/count")

    assert response.status_code in [200, 400]


# ---------------------------------------------------------
# POST request tests
# ---------------------------------------------------------

def test_post_valid_json(client):
    """
    Verifies that the POST /count endpoint correctly processes valid JSON.

    This test confirms that the API accepts the documented JSON request format
    and returns the correct word count.
    """
    response = client.post(
        "/count",
        json={"text": "one two three four"}
    )

    assert response.status_code == 200

    data = json.loads(response.data)
    assert data["count"] == 4


def test_post_empty_json(client):
    """
    Verifies how the API responds when an empty JSON object is submitted.

    This test is important because the expected text field is missing.
    The API should return a controlled response instead of failing unexpectedly.
    """
    response = client.post(
        "/count",
        json={}
    )

    assert response.status_code in [200, 400]


def test_post_null_value(client):
    """
    Verifies how the API responds when the text field contains a null value.

    Null input may cause a type error if the server assumes that all text values
    are strings. This test identifies whether additional validation is needed.
    """
    response = client.post(
        "/count",
        json={"text": None}
    )

    assert response.status_code in [200, 400, 500]